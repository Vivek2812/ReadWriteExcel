package com.ethans.xpathandpoi.xpathandpoi;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteToNewSheet {
	
	static XSSFRow row;
	   public static void main(String[] args) throws Exception {
	      FileInputStream fis = new FileInputStream(new File("src/main/resources/New.xlsx"));
	      
	      XSSFWorkbook workbook = new XSSFWorkbook(fis);
	      XSSFSheet spreadsheet = workbook.getSheetAt(0);
	      Iterator < Row >  rowIterator = spreadsheet.iterator();

	   }
	   
}
